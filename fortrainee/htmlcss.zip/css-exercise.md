# CSS Exercise

* This exercise is taken from Mitrais e-learning Internal Training


## Instruction
* Styling your Tourism web pages in previous exercise. 
* Using external stylesheet (eg. style.css).
* Using selector: id, class, pseudo-class, attribute, and element.
* Create different theme for page 2: article 2 (article.html).
* Open book.. Googling & discussion with friend is allowed. 
* Dont be a copycat, though.
* Be unique & creative.


## Submitting your result
* Zip your work and named it using this format ```HTML_Exercise_<yourname>.zip```, eg: ```HTML_Exercise_WellyaSeptin.zip```
* Send result to email: bayu.rizaldhanrayes@mitrais.com
